## Write a for loop that prints the entries of the following list, one at a time:
words = ["Wow,", "python", "is", "really", "cool."]

##TODO

## Write a for loop that computes 2^n only using multiplication by 2
n = 5

##TODO


## Write a for loop that adds 1 to elements in a list and prints their squared value
nums = [0, 3, -2, -1]

##TODO

