d = {"tree": "wood", "flower": "petal", "earth": "water", 101: [4, 6, 8]}

# TODO: INSERT CODE HERE TO REPLACE "wood" WITH "leaves"

# TODO: INSERT CODE HERE TO ADD THE PAIR "monty": "python"

# TODO: INSERT CODE HERE TO FIRST CHECK IF "earth" IS A KEY,
# AND IF IT IS THEN PRINT THE VALUE IT MAPS TO

# TODO: INSERT CODE HERE TO PRINT ALL THE PAIRS IN d

print(d) # check all your work
