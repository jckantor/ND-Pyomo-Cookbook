a = [1, 2, 3, 4, 5]

# TODO: INSERT CODE HERE TO REPLACE THE '1' IN a WITH THE STRING "foo"

print("a is:", a) # check your work

# TODO: INSERT CODE HERE TO REPLACE THE '4' IN a WITH THE STRING "bar"

print("a is:", a) # check your work

# TODO: INSERT CODE HERE TO PRINT WHAT YOU THINK 'print(a[-1])' WILL PRINT

print("a[-1] is:", a[-1]) # check your work (don't just write this for your answer!)

# TODO: INSERT CODE HERE TO MODIFY a SO IT IS [1, 2, "hello", "world", 4, 5]

print("a is:", a) # check your work

b = a
b[2] = "small"

# TODO: INSERT CODE HERE TO PRINT WHAT YOU THINK 'print(a[2])' WILL PRINT

print("a[2] is:", a[2]) # check your work (don't just write this for your answer!)

c = [x for x in range(2, 10)] # this is a list comprehension!

# TODO: INSERT CODE HERE TO PRINT WHAT YOU THINK 'print(c[3])' WILL PRINT

print("c[3] is:", c[3]) # check your work (don't just write this for your answer!)

d = [6, 5, 4, 3, 2]

# TODO: INSERT CODE HERE TO USE LIST COMPREHENSION TO CREATE THE FOLLOWING LIST:
# [7, 6, 5, 4, 3]
# USING THE LIST d GIVEN ABOVE. THEN PRINT IT.
